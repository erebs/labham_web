<?php
namespace App\Imports;
use App\Products;
use Illuminate\Support\Facades\Hash;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
class UsersImport implements ToModel
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        return new Products([
        
         'id'  => $row[0],
         'cat_id'   => $row[1],
         'subcat_id'   => $row[2],
         'brand_id'   => $row[3],
         'stock_avalible'    => $row[4],
         'name'  => $row[5],
         'desc'   => $row[6],
         'price'  => $row[7],
         'offerprice'   => $row[8],
         'best_seller'  => $row[9],
         'featured'   => $row[10],
         'trending'  => $row[11],
         'status'   => $row[12],
         'image'  => $row[13],
         'image2'   => $row[14],
         'image3'  => $row[15],
         'image4'   => $row[16],
        ]);



    }
}