<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductUnits extends Model
{
  public $timestamps = false;
}
