<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Category;
use App\Products;
use App\Banners;
use App\Customers;
use App\Address;
use App\Cart;
use App\temp_cart;
use App\Order;
use App\OrderedItems;
use Illuminate\Http\Response;

use Auth;
use Session;

class FrontendController extends Controller
{
    public function about()
    {
        return view('frontend.aboutus');
    }
    public function contact()
    {
        return view('frontend.contactus');
    }
    public function products()
    {
        $prod=Products::where('delstatus','Active')->get();
        return view('frontend.products',['prod'=>$prod]);
    }
     public function blog()
    {
        return view('frontend.blog');
    }
    public function home()
    {
           

          
        $cat=Category::where('status','Active')->orderBy('disporder','ASC')->limit(4)->get();
        $banners = Banners::where('type', '1')->orderBy('id', 'asc')->get();
        $pop=Products::where('delstatus','Active')->where('best_seller', '1')->orderBy('id','DESC')->limit(4)->get();
        return view('frontend.index',['cat'=>$cat,'banners'=>$banners,'pop'=>$pop]);
    }

    public function categories()
    {
        $cat=Category::where('status','Active')->orderBy('disporder','ASC')->get();
        return view('frontend.category',['cat'=>$cat]);
    }

    public function category_products($cid)
    {
        $catid=decrypt($cid);
        $cat=Category::select('name')->where('id',$catid)->first();
        $prod=Products::where('delstatus','Active')->where('cat_id', $catid)->get();
        return view('frontend.category_products',['prod'=>$prod,'cat'=>$cat]);
    }

     public function productsingle($cid)
    {
        $pid=decrypt($cid);
        $prod=Products::where('id',$pid)->first();
        $relprod=Products::where('delstatus','Active')->where('id','!=', $prod->id)->orderBy('id','DESC')->limit(4)->get();
        return view('frontend.productsingle',['prod'=>$prod,'relprod'=>$relprod]);
    }

     public function signin()
    {
        return view('frontend.login');
    }

    public function signup()
    {
        return view('frontend.signup');
    }


    public function user_signup(Request $req)
    {

        if(Customers::where('phone',$req->mobile)->exists())
        {
            $data['err']="Mobile number already exists";
        }
        else
        {
            Customers::create([

                'name'=>$req->name,
                'phone'=>$req->mobile,
                'password'=>bcrypt($req->pass)


            ]);
            $data['success']="Registration completed successfully";

         }
         echo json_encode($data);
       
    }


    public function user_signin(Request $req)
    {
        
        $uname=$req->mobile;
        $psw=$req->pass;

           if(Auth::guard('member')->attempt(['phone' => $uname, 'password' => $psw]))
                {
                    $data['success']='Login success.Please wait...';


                    $sessionVariableName = 'tempuser';

                if (Session::has($sessionVariableName)) {
                $sessionValue = Session::get($sessionVariableName);
                $tempcart=temp_cart::where('uniqueid',$sessionValue)->get();
                // $mycart=Cart::where('uniqueid',Auth::guard('member')->user()->id)->get();
                foreach($tempcart as $tm)
                    {
                        if(Cart::where('productid',$tm->productid)->exists())
                        {
                            $mycart=Cart::where('uniqueid',Auth::guard('member')->user()->id)->where('productid',$tm->productid)->first();
                            Cart::where('uniqueid',Auth::guard('member')->user()->id)->where('productid',$tm->productid)->update([

                                'quantity'=>$mycart->quantity+$tm->quantity,

                            ]);
                        }
                        else
                        {
                          Cart::create([

                            'uniqueid'=>Auth::guard('member')->user()->id,
                            'productid'=>$tm->productid,
                            'unitid'=>$tm->unitid,
                            'color_id'=>$tm->color_id,
                            'quantity'=>$tm->quantity,
                            'created_at'=>date('Y-m-d H:i:s')
                            ]);  
                        }

                        temp_cart::where('id',$tm->id)->delete();

                    }
                }
                



                }
            else
                {
                    $data['err']='Invalid user !';
                }    
        

        echo json_encode($data);
    }









    public function profile()
    {
        $add=Address::where('user_id',auth()->guard('member')->user()->id)->where('status','Active')->orderBy('id','DESC')->get();
        return view('frontend.profile',['add'=>$add]);
    }

     public function edit_profile(Request $req)
    {

           if(Customers::where('phone',$req->mobile)->where('id','!=',auth()->guard('member')->user()->id)->exists())
                {
                    $data['err']='Mobile number already exists';
                }
           else if(Customers::where('email',$req->mail)->where('id','!=',auth()->guard('member')->user()->id)->exists())
                {
                    $data['err1']='Mail Id already exists';
                }    
            else
                {
                    Customers::where('id',auth()->guard('member')->user()->id)->update([

                        'name'=>$req->name,
                        'phone'=>$req->mobile,
                        'email'=>$req->mail,

                    ]);
                    $data['success']='success';
                }    
        

        echo json_encode($data);
    }

    public function logout()
    {
        Auth::guard('member')->logout();
        return redirect()->route('home');
    }

     public function addaddress()
    {
        return view('frontend.addaddress');
    }

    public function address_add(Request $req)
    {

        if(Address::where('user_id',auth()->guard('member')->user()->id)->where('status','Active')->exists())
        {
            $default='0';
        }
        else
        {
          $default='1';  
        }

        Address::create([

                        'user_id'=>auth()->guard('member')->user()->id,
                        'default'=>$default,
                        'name'=>$req->name,
                        'mobile'=>$req->mobile,
                        'address'=>$req->address,
                        'district'=>$req->dist,
                        'state'=>$req->st,
                        'pincode'=>$req->pincode,
                        'landmark'=>$req->land,


                    ]);
                    $data['success']='success';
               
        echo json_encode($data);
    }

    public function def_address(Request $req)
    {


        Address::where('id',$req->aid)->update([

                        'default'=>'1',
                    ]);

        Address::where('user_id',auth()->guard('member')->user()->id)->where('id','!=',$req->aid)->update([

                        'default'=>'0',
                    ]);



                    $data['success']='success';
               
        echo json_encode($data);
    }

     public function editaddress($aid)
    {
        $adid=decrypt($aid);
        $add=Address::where('id',$adid)->first();
        return view('frontend.editaddress',['add'=>$add]);
    }

       public function address_edit(Request $req)
    {

        Address::where('id',$req->aid)->update([

                        'name'=>$req->name,
                        'mobile'=>$req->mobile,
                        'address'=>$req->address,
                        'district'=>$req->dist,
                        'state'=>$req->st,
                        'pincode'=>$req->pincode,
                        'landmark'=>$req->land,


                    ]);
                    $data['success']='success';
               
        echo json_encode($data);
    }

      public function delete_address(Request $req)
    {
        $chkdef=Address::where('id',$req->body)->first();
        if($chkdef->default=='1')
        {
           Address::where('id',$req->body)->update([

                        'status'=>'Deleted',
                    ]);
           $add=Address::where('user_id',auth()->guard('member')->user()->id)->where('status','Active')->orderBy('id','DESC')->limit(1)->first();
           Address::where('id',$add->id)->update([

                        'default'=>'1',
                    ]);
                    $data['success']='success'; 
        }

        else
        {
           Address::where('id',$req->body)->update([

                        'status'=>'Deleted',
                    ]);
            $data['success']='success';         
        }
        
               
        echo json_encode($data);
    }

    ////////////////


    public function cart()
    {
        $uid=auth()->guard('member')->user()->id;
        $cart=Cart::where('uniqueid',$uid)->orderBy('id','DESC')->get();
        return view('frontend.cart',['cart'=>$cart]);
    }

     public function get_cartcount()
    {
        if(Auth::guard('member')->check())
        {
            $uid=auth()->guard('member')->user()->id;
            $cart=Cart::where('uniqueid',$uid)->orderBy('id','DESC')->sum('quantity');
            echo $cart;
        }
        else
        {
                $sessionVariableName = 'tempuser';

                if (Session::has($sessionVariableName)) {
                $sessionValue = Session::get($sessionVariableName);
                }
                else
                {
                $sessionValue=time();
                Session::put($sessionVariableName,$sessionValue);  
                }
            
            $uid=$sessionValue;
            $cart=temp_cart::where('uniqueid',$uid)->orderBy('id','DESC')->sum('quantity');
            echo $cart;  
        }    


          
    }


      public function add_to_cart(Request $req)
    {

        if(Auth::guard('member')->check())
        {
            $uid=auth()->guard('member')->user()->id;
            $chk=Cart::where('uniqueid',$uid)->where('productid',$req->pid)->first();
            if($chk)
            {
                   Cart::where('uniqueid',$uid)->where('productid',$req->pid)->update([

                    'quantity'=>$chk->quantity+1,

                   ]);
                $data['success']='success'; 
            }

            else
            {
               Cart::create([

                            'uniqueid'=>$uid,
                            'productid'=>$req->pid,
                            'unitid'=>0,
                            'color_id'=>0,
                            'quantity'=>1,
                            'created_at'=>date('Y-m-d H:i:s')
                        ]);
                $data['success']='success';         
            }
        }
        else
        {
            $sessionVariableName = 'tempuser';

                if (Session::has($sessionVariableName)) {
                $sessionValue = Session::get($sessionVariableName);
                }
                else
                {
                $sessionValue=time();
                Session::put($sessionVariableName,$sessionValue);  
                }
            
            $uid=$sessionValue;
            $chk=temp_cart::where('uniqueid',$uid)->where('productid',$req->pid)->first();
            if($chk)
            {
                   temp_cart::where('uniqueid',$uid)->where('productid',$req->pid)->update([

                    'quantity'=>$chk->quantity+1,

                   ]);
                $data['success']='success'; 
            }

            else
            {
               temp_cart::create([

                            'uniqueid'=>$uid,
                            'productid'=>$req->pid,
                            'unitid'=>0,
                            'color_id'=>0,
                            'quantity'=>1,
                            'created_at'=>date('Y-m-d H:i:s')
                        ]);
                $data['success']='success';         
            }
               
     
        }

           echo json_encode($data);
    }

        public function add_cart(Request $req)
    {
        if(Auth::guard('member')->check())
        {
                $uid=auth()->guard('member')->user()->id;
                $chk=Cart::where('uniqueid',$uid)->where('productid',$req->pid)->first();
                if($chk)
                {
                       Cart::where('uniqueid',$uid)->where('productid',$req->pid)->update([

                        'quantity'=>$chk->quantity+$req->qty,

                       ]);
                    $data['success']='success'; 
                }

                else
                {
                   Cart::create([

                                'uniqueid'=>$uid,
                                'productid'=>$req->pid,
                                'unitid'=>0,
                                'color_id'=>0,
                                'quantity'=>$req->qty,
                                'created_at'=>date('Y-m-d H:i:s')
                            ]);
                    $data['success']='success';         
                }
        }
        else
        {

             $sessionVariableName = 'tempuser';

                if (Session::has($sessionVariableName)) {
                $sessionValue = Session::get($sessionVariableName);
                }
                else
                {
                $sessionValue=time();
                Session::put($sessionVariableName,$sessionValue);  
                }
            
            $uid=$sessionValue;
                $chk=temp_cart::where('uniqueid',$uid)->where('productid',$req->pid)->first();
                if($chk)
                {
                       temp_cart::where('uniqueid',$uid)->where('productid',$req->pid)->update([

                        'quantity'=>$chk->quantity+$req->qty,

                       ]);
                    $data['success']='success'; 
                }

                else
                {
                   temp_cart::create([

                                'uniqueid'=>$uid,
                                'productid'=>$req->pid,
                                'unitid'=>0,
                                'color_id'=>0,
                                'quantity'=>$req->qty,
                                'created_at'=>date('Y-m-d H:i:s')
                            ]);
                    $data['success']='success';         
                }

        }
        
               
        echo json_encode($data);
    }


     public function delete_cart(Request $req)
    {
        
           Cart::where('id',$req->cid)->delete();
            $data['success']='success';         
               
            echo json_encode($data);
    }

    public function plus_cart(Request $req)
    {
        
           Cart::where('id',$req->cid)->update([

            'quantity'=>$req->qty+1,

           ]);
            $data['success']='success';         
               
            echo json_encode($data);
    }

     public function minus_cart(Request $req)
    {
        
           Cart::where('id',$req->cid)->update([

            'quantity'=>$req->qty-1,

           ]);
            $data['success']='success';         
               
            echo json_encode($data);
    }


        public function checkout()
    {
        $uid=auth()->guard('member')->user()->id;
        $cart=Cart::where('uniqueid',$uid)->orderBy('id','DESC')->get();
        $addresses=Address::where('user_id',$uid)->where('status','Active')->orderBy('id','DESC')->get();
        return view('frontend.checkout',['cart'=>$cart,'addresses'=>$addresses]);
    }

      public function placeorder(Request $req)
    {
        $uid=auth()->guard('member')->user()->id;
        $cart=Cart::where('uniqueid',$uid)->orderBy('id','DESC')->get();

        $order=Order::create([

                'customerid'=>auth()->guard('member')->user()->id,
                'addressid'=>$req->address,
                'paytype'=>$req->paytype,
                'paymentid'=>$req->refid,
                'details'=>$req->note,

            ]);
        $lastInsertedId = $order->id;

        foreach($cart as $c)
        {
           OrderedItems::create([

                'orderid'=>$lastInsertedId,
                'productid'=>$c->productid,
                'quantity'=>$c->quantity,
                

            ]); 

           Cart::where('id',$c->id)->delete();
        }

        $data['success']="success";
        echo json_encode($data);
    }
}
